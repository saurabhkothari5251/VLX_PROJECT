package com.vlx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VlxWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(VlxWebApplication.class, args);
	}

}
