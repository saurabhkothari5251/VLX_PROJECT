package com.vlx.vo;

public class CategoryVo {

private long id;
	


public long getId() {
	return id;
}

public void setId(long id) {
	this.id = id;
}

public String getCategoryname() {
	return categoryname;
}

public void setCategoryname(String categoryname) {
	this.categoryname = categoryname;
}

private String categoryname;
}
